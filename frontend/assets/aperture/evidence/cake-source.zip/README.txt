APERTURE DEMO V4 — THE CAKE IS A LIE, THE MESH IS WATERTIGHT

Original editable yapCAD DSL authored for this demo. No downloaded cake geometry, scans, image generation or third-party model assets were used. Native yapCAD mesh primitives and Boolean operations produce all geometry. The runtime is yapCAD 1.1.0, mesh/manifold3d backend (no BREP). Colors are deterministic presentation styling of the native mesh's connected components, applied by style_run.py; geometry is unchanged by styling.

MAIN DELIVERABLES
cake.dsl — authoritative editable source with visible filling/frosting/explode controls and a separate printable command.
thermoplastic-cake.stl — SINGLE PIECE PRINT EDITION, millimetres, 108 x 108 x 60, flat z=0 underside; 14,690 triangles. One watertight, consistently oriented positive-volume body, independently reloaded and checked. See print-validation.json. Thick attached cherries and cream remain; delicate stems, candle/flame and sprinkles are omitted. This is printable decorative geometry, not an edible cake or recipe. No physical print trial was performed. Choose supports and other slicer settings for your printer/material.
initial-native-pane.png / revised-native-pane.png — actual browser captures of the native parameter pane and WebGL model, before and after the visible filling revision.
initial-hero.png / revised-hero.png / exploded-hero.png / print-hero.png — real yapCAD CLI tool renders, not painted concept art. The simple tool rasterizer has occasional triangle-sorting artifacts; prefer native-hero/native-pane captures for the exhibit hero.
initial-native-hero.png / revised-native-hero.png / exploded-native-hero.png — clean native WebGL viewports.
print-native-pane.png — print command, one-body/watertight stats and model.
inspection-and-revision.txt — actual inspection finding and revision rationale.
manifest.json — exact paths, retained run identifiers and capture guidance.

RETAINED RUNS
Initial thin filling: 20261009T191747261301-78e5c598
Revised filling:     20261009T191952722307-4f4b4da6
Exploded layers:     20261009T192023211721-a077599f
Single-piece print:  20261009T191757837326-7620d093
Runs live under /home/meawoppl/repos/scratch/.yapcad-runs/RUN_ID, with native source.dsl snapshots, view.json, model.stl, preview.png and run.json/run.log.

VISIBLE REVISION
Inspect initial 0.8 mm berry filling / 3 mm frosting with three sponge layers. The berry layer reads as a hairline. Revise filling to 6 mm, frosting to 7 mm; keep visual layer separation 1.5 mm. A later 8 mm exploded spacing separates the ingredients further. Preserve those exact pane values in captures. Say: "The filling was inadequate. We opened an issue against dessert."

PRINT VS DISPLAY
The colorful presentation is an assembly of separate closed layer and garnish solids, suitable for exploration and exploded views; it is NOT the single-piece download. The print command fuses an assembled cake/plate silhouette and attached substantial garnish into one continuous solid. It retains the cake form and frosting but has no color/material assignments in STL. Layer seams are not separate internal print shells.

REBUILD
/home/meawoppl/agent-portal-plugins/yapcad/bin/yapcad build --cwd /home/meawoppl/repos/scratch --file cake-demo-v4/cake.dsl --command CAKE_IS_A_LIE -p filling=6 -p frosting=7 -p explode=1.5 --export stl
/home/meawoppl/agent-portal-plugins/yapcad/bin/yapcad build --cwd /home/meawoppl/repos/scratch --file cake-demo-v4/cake.dsl --command THERMOPLASTIC_CAKE -p print_scale=0.6 --export stl

Write the JSON tool result to a report file and pass it to style_run.py with the plugin Python to reproduce component colors. For a camera-consistent real tool render use --view=-1.4,-2,1.2 --size 1400x1100. Native view camera is [-150,-255,185], target [65,0,48]. Set TMPDIR to the short workspace .cad-tmp path for headless Chromium.

The abandoned rocket draft is preserved separately in rocket-engine-demo-v4/engine.dsl. It is NOT a completed or validated deliverable and is excluded from the cake download bundle.

VIDEO
cake-native-demo-1080p.mp4: 26.97 seconds, 1920x1080, 30 fps, H.264/yuv420p, no audio. Real browser recording of actual native field edits, matching retained-run selections, then exploded model orbit. Initial page-load footage trimmed. This is an edited replay of inspected builds, not a claim about live build latency.
