import asyncio,json,tempfile,os,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent;tempfile.tempdir=str(ROOT.parent/'.cad-tmp');os.environ['TMPDIR']=tempfile.tempdir
runs=json.loads((ROOT/'manifest.json').read_text())['retained_runs']
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/home/meawoppl/.cache/ms-playwright/chromium-1228/chrome-linux64/chrome',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage'])
  context=await b.new_context(viewport={'width':1920,'height':1080},record_video_dir=str(ROOT/'raw-video'),record_video_size={'width':1920,'height':1080})
  t0=time.monotonic();page=await context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto('http://127.0.0.1:37839/');await page.wait_for_function('window.workbench?.info?.runs?.length>0');await page.locator('#live').uncheck();await page.locator('#file').select_option('cake-demo-v4/cake.dsl');await page.locator('#command').select_option('CAKE_IS_A_LIE');await page.locator('#grid').uncheck();await page.locator('#edges').uncheck()
  async def select(k,vals):
   await page.locator('#runs').select_option(runs[k]);await page.wait_for_function('(rid)=>workbench.run?.id===rid && scene3d.model.children.length>1',arg=runs[k])
   for i,v in enumerate(vals):await page.locator('#params input[type=number]').nth(i).fill(str(v))
   await page.evaluate('scene3d.camera.position.set(-125,-225,175);scene3d.controls.target.set(65,0,55);scene3d.controls.update()')
   await page.wait_for_timeout(400)
  await select('initial',[.8,3,1.5]);start=time.monotonic()-t0;await page.screenshot(path=str(ROOT/'video-initial-1080.png'));await page.wait_for_timeout(4400)
  # Actual native control edits, followed by the matching previously built revision.
  await page.locator('#params input[type=number]').nth(0).fill('6');await page.wait_for_timeout(650);await page.locator('#params input[type=number]').nth(1).fill('7');await page.wait_for_timeout(650)
  await select('revised',[6,7,1.5]);await page.screenshot(path=str(ROOT/'video-revised-1080.png'));await page.wait_for_timeout(5200)
  await page.locator('#params input[type=number]').nth(2).fill('8');await page.wait_for_timeout(650);await select('exploded',[6,7,8]);await page.evaluate('scene3d.camera.position.set(-185,-290,230);scene3d.controls.target.set(65,0,95);scene3d.controls.update()');await page.screenshot(path=str(ROOT/'video-exploded-1080.png'));await page.wait_for_timeout(1800)
  await page.evaluate('''() => new Promise(resolve => { const start=performance.now(), duration=8000, initial=Math.atan2(-290,-250), radius=Math.hypot(290,250);function frame(t){const u=Math.min((t-start)/duration,1), angle=initial+u*1.7;scene3d.camera.position.set(65+radius*Math.cos(angle),radius*Math.sin(angle),230);scene3d.controls.target.set(65,0,95);scene3d.controls.update();if(u<1)requestAnimationFrame(frame);else resolve();}requestAnimationFrame(frame);})''')
  await page.wait_for_timeout(1400);end=time.monotonic()-t0;video=await page.video.path();await context.close();await b.close();assert not errors,errors
  (ROOT/'video-timing.json').write_text(json.dumps({'raw':str(video),'trim_start_seconds':start,'duration_seconds':end-start,'capture':'Real native pane, actual control edits and selection of retained builds; orbit is real WebGL camera motion. No build-time claim on this edited capture.','errors':errors},indent=2));print(start,end-start,video,flush=True)
asyncio.run(main())
