import asyncio,json,tempfile,os,sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent;tempfile.tempdir=str(ROOT.parent/'.cad-tmp');os.environ['TMPDIR']=tempfile.tempdir
rid=sys.argv[1];prefix=sys.argv[2]
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/home/meawoppl/.cache/ms-playwright/chromium-1228/chrome-linux64/chrome',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage'])
  page=await b.new_page(viewport={'width':1500,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto('http://127.0.0.1:37839/');await page.wait_for_function('window.workbench?.info?.runs?.length>0');await page.locator('#live').uncheck();await page.locator('#file').select_option('cake-demo-v4/cake.dsl');await page.locator('#command').select_option('THERMOPLASTIC_CAKE' if prefix=='print' else 'CAKE_IS_A_LIE');await page.locator('#runs').select_option(rid);await page.wait_for_function('(rid)=>workbench.run?.id===rid && scene3d.model.children.length>0',arg=rid)
  values={'initial':[0.8,3.0,1.5],'revised':[6.0,7.0,1.5],'exploded':[6.0,7.0,8.0]}.get(prefix)
  if values:
   for i,v in enumerate(values):await page.locator('#params input[type=number]').nth(i).fill(str(v))
  await page.locator('#grid').uncheck();await page.locator('#edges').uncheck();await page.wait_for_timeout(750)
  await page.screenshot(path=str(ROOT/(prefix+'-native-pane.png')));await page.locator('#viewport').screenshot(path=str(ROOT/(prefix+'-native-hero.png')))
  print(await page.locator('#params').inner_text());print('errors',errors);assert not errors;await b.close()
asyncio.run(main())
