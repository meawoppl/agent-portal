"""Deterministic presentation colors on connected components of the native DSL mesh."""
from pathlib import Path
import json,sys,base64,numpy as np,trimesh,shutil
ROOT=Path(__file__).resolve().parent;report=json.loads(Path(sys.argv[1]).read_text());run=ROOT.parent/'.yapcad-runs'/report['id'];m=trimesh.load(report['files']['stl'],process=True);components=m.split(only_watertight=False)
assert all(c.is_watertight for c in components)
large=sorted([c for c in components if c.extents[0]>70],key=lambda c:c.bounds[0,2]);layers=['ceramic serving plate','vanilla base','chocolate sponge 1','berry filling 1','cream seam 1','chocolate sponge 2','berry filling 2','cream seam 2','chocolate sponge 3','vanilla frosting']
palette=[[.58,.73,.81],[.98,.88,.67],[.26,.095,.045],[.65,.035,.14],[1.,.93,.8],[.31,.12,.055],[.65,.035,.14],[1.,.93,.8],[.28,.10,.045],[1.,.93,.8]]
parts=[];sprinkle=0
for i,c in enumerate(components):
 ix=next((k for k,d in enumerate(large) if d is c),None)
 if ix is not None:name=layers[ix];color=palette[ix]
 elif c.extents[2]<2:name='sugar sprinkle';color=[[.98,.45,.62],[.22,.78,.78],[.99,.7,.18],[.70,.48,.92]][sprinkle%4];sprinkle+=1
 elif c.extents[0]>14 and c.extents[1]>14:name='cherry';color=[.64,.025,.065]
 elif c.extents[2]>24:name='candle';color=[.12,.68,.72]
 elif c.extents[2]<5:name='wick';color=[.12,.09,.06]
 elif c.extents[0]>8 and c.extents[1]>8:name='piped cream';color=[1.,.94,.81]
 elif c.extents[0]>6 and c.extents[1]>6:name='decorative flame';color=[1.,.55,.08]
 else:name='cherry stem';color=[.18,.39,.13]
 parts.append({'name':name,'color':color,'positions':base64.b64encode(c.triangles.astype('<f4').tobytes()).decode(),'edges':'','stats':{'triangles':len(c.faces)}})
view={'kind':'solid','parts':parts,'camera':{'position':[-150,-255,185],'target':[65,0,48]}};(run/'view.json').write_text(json.dumps(view,separators=(',',':')))
rec=json.loads((run/'run.json').read_text());rec.setdefault('notes',[]).append('Original presentation cake. Deterministic component colors applied by cake-demo-v4/style_run.py to the unmodified native DSL mesh. Display layers are separate; use THERMOPLASTIC_CAKE for single-piece printing.');rec['label']='THE CAKE IS A LIE — '+('thin filling / inspect' if 'initial' in sys.argv[1] else 'filling repaired / revised');(run/'run.json').write_text(json.dumps(rec,indent=2));print(report['id'],len(parts),'closed parts',flush=True)
