# FSM driver film visuals (recorded hardware data)

Stills and replays of recorded bench data from the CF-00020-01 FSM driver
running firmware v4.1.0 (2026-10-09, Nucleo bench fixture). See
`evidence/PROVENANCE.md` for sources, numbers, and limits.

Regenerate everything from `evidence/`:

```bash
python3 render.py            # add --no-video for the PNGs only
```

It needs Python 3 with numpy and matplotlib, plus ffmpeg with libx264.
`collect_evidence.sh` refreshes `evidence/` from `~/fsm-lab/runs/`; you need it
only if the source recordings change.

| File | Content |
|---|---|
| `circle.png`, `circle.mp4` | 800 µrad circle, commanded against measured, with the error strip; the MP4 replays two laps at real time |
| `steps.png` | +100 µrad step on x and y, with rise and settling |
| `b5-commit.png`, `b5-commit.mp4` | Calibration-record flash commit: the 1000.5 ms telemetry pause and the request/reply timeline; the MP4 runs slowed 10× (100× for the first 26 ms) |
| `computed.json` | Every number drawn on the visuals |
