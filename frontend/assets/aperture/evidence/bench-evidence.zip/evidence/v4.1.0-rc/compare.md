| Measure | This run | Baseline (2026-10-06 first light) |
|---|---|---|
| step x: mean gain | 1.0001 | 1.0001 |
| step x: settled noise RMS µrad | 0.10 | 0.09 |
| step x: frames with error flags | 0 | 0 |
| step y: mean gain | 1.0000 | 1.0001 |
| step y: settled noise RMS µrad | 0.09 | 0.10 |
| step y: frames with error flags | 0 | 0 |
| circle-frames: commanded_extent_urad | 800.0000 | 800.0000 |
| circle-frames: gain_on_circle x | 1.0009 | 1.0012 |
| circle-frames: gain_on_circle y | 1.0010 | 1.0012 |
| circle-frames: measured_extent_urad | 934.9000 | 934.7000 |
| circle-frames: frame rate Hz | 1988.0 | 1993.6 |
| circle-frames: frames with error flags | 0 | 0 |
| circle-frames: tracking_error_max_urad | 19.9000 | 79.7000 |
| circle-frames: tracking_error_rms_urad | 13.7000 | 16.6000 |
| schroeder x: gain at 10 / 50 / 100 / 150 Hz (dB) | 0.4 / -4.1 / -11.3 / -13.9 | -0.2 / -5.8 / -12.7 / -18.4 |
| schroeder x: phase at 10 / 50 / 100 Hz | -27° / -125° / +151° | -32° / -127° / +152° |
| schroeder y: gain at 10 / 50 / 100 / 150 Hz (dB) | -0.2 / -3.9 / -10.1 / -15.2 | -0.1 / -5.9 / -13.2 / -18.8 |
| schroeder y: phase at 10 / 50 / 100 Hz | -26° / -130° / +149° | -29° / -132° / +152° |
