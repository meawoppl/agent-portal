# Provenance: FSM driver film visuals

Every visual in this package is rendered from recorded bench data. Nothing in
it is live, simulated, or re-measured; the videos are deterministic replays of
the recordings. No hardware was touched to make it.

## Hardware and firmware

- **Board:** CF-00020-01 fast steering mirror driver, dual-core STM32H755
  (Cortex-M7 host link, Cortex-M4 closed loop). One bench board.
- **Host:** the Nucleo bench fixture (`fsm-test-fixture`, a Nucleo board
  bridging the FSM's UART to the bench PC). This is a test fixture, not the
  flight host.
- **Firmware for the tracking runs:** v4.1.0, release
  <https://github.com/CosmicFrontierLabs/fsm-driver-firmware/releases/tag/v4.1.0>,
  images built from commit `7b9d842`. The board reported
  `version 4.1.1.7b9d8428.10` at boot (`v4.1.0-rc/version.txt`).
  The flashed images are byte-identical to the release assets:

  | Image | SHA-256 (run `SHA256SUMS`) | Release asset with the same SHA-256 |
  |---|---|---|
  | `fsm-cm7.elf` | `d184aae8…3eb9966` | `CF-00020-01-V4.1.7b9d842_CM7.elf` |
  | `fsm-cm4.elf` | `e9ee1604…7618269018` | `CF-00020-01-V4.1.1.7b9d842_CM4_Perf.elf` |

  Compare `v4.1.0-rc/SHA256SUMS` with `release-v4.1.0-SHA256SUMS` (downloaded
  from the release with `gh release download`).
- **Firmware for the B5 commit:** `fac4afa` (the board reports fw 4.0.1, git
  `fac4afab`, in `b5-manual/commit.log` and `prep.log`). The calibration-record
  commit path is carried unchanged into v4.1.0; that statement comes from the
  release notes and the bench owner, not from this package.

## Recording dates

- v4.1.0 bench run: 2026-10-09, 16:17Z to 16:24Z (`v4.1.0-rc/run.log`);
  follow-on wire checks to 16:31Z (`v410-bench.out`).
- B5 commit: 2026-10-08 22:28 PDT, i.e. 2026-10-09 05:28Z
  (`b5-manual/commit.log`).

## Source files

The originals live under `~/fsm-lab/runs/` and were read, never changed.
`collect_evidence.sh` copies them here. All copies are whole files; nothing is
trimmed. `EVIDENCE-SHA256SUMS` lists the hash of every copy.

| Copy in `evidence/` | Original | What it is |
|---|---|---|
| `v4.1.0-rc/circle-frames.csv` | `~/fsm-lab/runs/v4.1.0-rc/circle-frames.csv` | Circle disturbance run: every telemetry frame at about 2 kHz, 17 893 rows, 9.0 s |
| `v4.1.0-rc/circle-frames.circle.json` | same dir | Host tool's circle fit: radius 800 µrad, 2 s lap, gain, lag, 16.55 µrad rms |
| `v4.1.0-rc/step-x.csv`, `step-y.csv` | same dir | Step-ladder runs (±20, 40, 100, 200, 400 µrad, 1 s pulses), 21 s each |
| `v4.1.0-rc/analysis/summary.json` | same dir, `analysis/` | Release analysis (`fsm-test-fixture/analysis/baseline.py`) of the runs |
| `v4.1.0-rc/compare.md` | same dir | This run against the 2026-10-06 first-light baseline |
| `v4.1.0-rc/version.txt` | same dir | Boot version packet |
| `v4.1.0-rc/flash.log` | same dir | Whole flash log (486 bytes, so copied in full rather than excerpted) |
| `v4.1.0-rc/SHA256SUMS` | same dir | Hashes of the two images flashed |
| `v4.1.0-rc/run.log` | same dir | Bench script transcript |
| `v410-bench.out` | `~/fsm-lab/runs/v410-bench.out` | Bench summary, including the wire-check totals |
| `release-v4.1.0-SHA256SUMS` | GitHub release v4.1.0 asset `SHA256SUMS` | Release image hashes |
| `b5-manual/commit-telemetry.csv` | `~/fsm-lab/runs/b5-manual/commit-telemetry.csv` | Telemetry around the commit: host ms (0 = first write request), board sequence, cycle, state, error word; 5 945 rows |
| `b5-manual/commit.log` | same dir | ms-stamped transcript of every request and reply during the commit |
| `b5-manual/prep.log`, `hold.log` | same dir | Context: the board was parked (Shutdown) before the commit; a write in Hold is refused |

## What each visual shows

All are 1920×1080, opaque `#1a1b26` background, and carry the banner
"RECORDED HARDWARE DATA — NOT LIVE" and a source line.

- **`circle.png`** — the whole circle run. Left: XY plane in µrad, commanded
  (blue) against measured (orange); at this scale the two traces overlap.
  Middle: a ±40 µrad window centred on the commanded point at one instant
  (t = 1.761 s), showing the measured point trailing along the path. Bottom:
  tracking-error magnitude against time, with the ramp from and back to the
  centre marked. Right: gain and error figures computed from the data.
- **`circle.mp4`** — the same layout replayed at real time (1×) over two laps,
  t = 1.5 s to 5.5 s of the run, drawn progressively; 30 fps, H.264, yuv420p,
  8.0 s (1 s hold at the start, 4 s of replay, 3 s hold at the end). Time is the
  host's frame-arrival clock.
- **`steps.png`** — the +100 µrad step on each axis from the step ladder, zoomed
  to −5…45 ms around the command edge, with the ±2 % band, the 10 % and 90 %
  points, and the settling time.
- **`b5-commit.png`** — the calibration-record commit. Top: board cycle of each
  telemetry frame against host time, showing the pause. Middle: every host
  request as a bar from send to reply, in lanes (the write and its resends;
  other requests answered Busy; status and version answered; setpoints that
  draw no reply). Bottom: the first 26 ms enlarged.
- **`b5-commit.mp4`** — the same figure revealed progressively against a host
  clock, 19.1 s: slowed 10× for most of it and 100× for the first 26 ms after
  the write; the title always states the rate in force.

## Figures computed from the data, and how they compare

Computed by `render.py` and written to `computed.json`.

| Measure | This package | Release bench | Note |
|---|---|---|---|
| Circle gain x / y | 1.0010 / 1.0009 | 1.0009 / 1.0010 | See (1) |
| Tracking error, whole run, rms / max | 13.7 / 19.9 µrad | 13.7 / 19.9 µrad | Matches |
| Tracking error, laps only, rms / max | 16.5 / 19.9 µrad | 16.55 / 19.86 µrad (host circle fit) | See (2) |
| Lag along the path | 6.6 ms, 13.1 cycles | same (taken from the circle fit) | Not recomputed |
| Step +100 µrad x: 10–90 % rise, 2 % settle, overshoot, gain | 8.5 ms, 17.6 ms, 0.4 %, 1.0000 | mean ladder gain 1.0001 | |
| Step +100 µrad y: same | 8.0 ms, 15.0 ms, 1.0 %, 1.0001 | mean ladder gain 1.0000 | |
| B5 telemetry gap | 1007.5 ms host; cycle step 2001 = 1000.5 ms board time (2000 cycles without a frame) | same in `commit.log` | Matches |
| B5 terminal reply | Complete at 1014.3 ms | same | Matches |

1. The task says to skip rows with blank cells, so this package drops the 623
   frames that the host read from a backlog and that carry no command. The
   release analysis instead fills those cells forward from the previous
   command. Run with forward filling, the same fit gives exactly 1.0009 / 1.0010
   (checked against `baseline.py`), so the release numbers reproduce. The two
   methods differ only in the fourth decimal, and the x and y values happen to
   swap.
2. "Whole run" (the release figure) includes the ramp from and back to the
   centre, where the error is small. Over the laps alone, the error is about
   16.5 µrad, almost entirely the 6.6 ms lag along the path (6.6 ms at
   2π·800 µrad / 2 s ≈ 16.5 µrad). This package counts as "laps" the frames
   whose commanded radius is at its peak; the host fit picks its own 11 559 frames,
   hence 16.47 here against 16.55 there.

Release-bench check results (from `run.log`, `v410-bench.out`, `summary.json`):
steps gain 1.0001 / 1.0000; circle gain 1.0009 / 1.0010; tracking error
13.7 µrad rms / 19.9 max; 0 frames with error flags (60 s telemetry, every
disturbance run); wire-session 16/16, re-arm 9/9, temperature 11/11, arrival
8/8 checks passed.

## How it was generated

- `collect_evidence.sh` copies the sources into `evidence/` and writes
  `EVIDENCE-SHA256SUMS`.
- `render.py` reads only `evidence/` and writes `circle.png`, `circle.mp4`,
  `steps.png`, `b5-commit.png`, `b5-commit.mp4` and `computed.json`. It uses
  Python 3 with numpy and matplotlib (3.10.8 here) and ffmpeg's libx264
  (single thread, bit-exact flags). Two consecutive runs produced
  byte-identical PNGs and MP4s on this machine; another matplotlib, font or
  ffmpeg build may change the pixels but not the numbers.

## Limits

- One bench board. These are not fleet statistics.
- The host is the Nucleo bench fixture, not the flight host. Host-side timing
  (frame arrival, request/reply times) reflects this PC and fixture.
- The videos are deterministic replays of recordings, not live data.
- The disturbance-run positions are in the host tool's µrad scale.
- The B5 commit ran on firmware `fac4afa`, not on the v4.1.0 images; the claim
  that v4.1.0 carries that path unchanged is taken from the release
  record, not shown by this data. The board was parked in Shutdown during the
  commit; the flash write is refused in Hold (`hold.log`).
- `flash.log` records "health gate: OVERRIDDEN — board was not verified
  healthy" for the v4.1.0 flash. That gate is the flash tool's pre-flash
  check. Every post-flash check listed above passed.
- `commit-telemetry.csv` holds a second cycle discontinuity, 4 470 cycles at
  host −1399 ms, among frames that arrived together as a backlog when the
  capture started. It lies outside the plotted window and is not part of the
  commit.
