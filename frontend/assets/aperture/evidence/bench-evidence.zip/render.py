#!/usr/bin/env python3
"""Render the film visuals from the recorded bench data in evidence/.

Everything here is a deterministic function of the files in evidence/: no
hardware, no network, no clock. Run `python3 render.py` (or `render.py
--no-video` for stills only). Outputs land beside this script.

Units: the disturbance-run CSVs carry positions in the host tool's µrad
scale; the B5 telemetry carries host milliseconds and board control cycles
(0.5 ms each).
"""

import argparse
import csv
import json
import math
import pathlib
import re
import subprocess

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import Rectangle  # noqa: E402
from matplotlib.transforms import blended_transform_factory  # noqa: E402

HERE = pathlib.Path(__file__).resolve().parent
EVIDENCE = HERE / "evidence"
RC = EVIDENCE / "v4.1.0-rc"
B5 = EVIDENCE / "b5-manual"

BG = "#1a1b26"
TEXT = "#c0caf5"
MUTED = "#565f89"
BLUE = "#7aa2f7"      # commanded
ORANGE = "#e0af68"    # measured
RED = "#f7768e"
GREEN = "#9ece6a"

W, H, DPI = 19.2, 10.8, 100   # 1920 x 1080 px; 1 pt = 1.39 px
FPS = 30

BANNER = "RECORDED HARDWARE DATA — NOT LIVE"
SOURCE = ("Source: CF-00020-01 FSM driver (STM32H755), firmware v4.1.0 "
          "(release images, build 7b9d842), recorded 2026-10-09 on the Nucleo bench fixture")
SOURCE_B5 = ("Source: CF-00020-01 (STM32H755), B5 commit on firmware fac4afa (unchanged in "
             "v4.1.0), recorded 2026-10-09 on the Nucleo bench fixture")

plt.rcParams.update({
    "figure.facecolor": BG, "axes.facecolor": BG, "savefig.facecolor": BG,
    "axes.edgecolor": MUTED, "axes.labelcolor": TEXT, "xtick.color": TEXT,
    "ytick.color": TEXT, "text.color": TEXT, "grid.color": MUTED, "grid.alpha": 0.45,
    "axes.grid": True, "legend.facecolor": BG, "legend.edgecolor": MUTED,
    "font.family": "DejaVu Sans", "font.size": 18, "axes.labelsize": 19,
    "xtick.labelsize": 18, "ytick.labelsize": 18, "legend.fontsize": 18,
    "axes.titlesize": 22, "savefig.transparent": False,
    "svg.hashsalt": "film", "path.simplify": False,
})


# ---------------------------------------------------------------- framing

def new_frame(title, source=SOURCE):
    """A 1920x1080 opaque figure with the not-live banner, a title and the
    source line already placed. Content goes between y=0.07 and y=0.83."""
    fig = plt.figure(figsize=(W, H), dpi=DPI)
    fig.patch.set_facecolor(BG)
    band = Rectangle((0, 0.925), 1, 0.075, transform=fig.transFigure,
                     facecolor="#2a1f2e", edgecolor="none", zorder=0)
    fig.add_artist(band)
    fig.add_artist(Rectangle((0, 0.925), 1, 0.004, transform=fig.transFigure,
                             facecolor=RED, edgecolor="none"))
    fig.text(0.5, 0.962, BANNER, ha="center", va="center", fontsize=30,
             fontweight="bold", color=RED)
    fig.text(0.02, 0.885, title, ha="left", va="center", fontsize=30,
             fontweight="bold", color=TEXT)
    fig.text(0.5, 0.018, source, ha="center", va="center", fontsize=17, color=MUTED)
    return fig


def save_png(fig, name):
    path = HERE / name
    fig.savefig(path, dpi=DPI, facecolor=BG, metadata={"Software": None})
    plt.close(fig)
    return path


class VideoWriter:
    """Pipes rendered 1920x1080 RGB frames to ffmpeg as H.264 / yuv420p."""

    def __init__(self, name):
        self.path = HERE / name
        self.proc = subprocess.Popen(
            ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24",
             "-s", "1920x1080", "-r", str(FPS), "-i", "-",
             "-c:v", "libx264", "-preset", "slow", "-crf", "16", "-pix_fmt", "yuv420p",
             "-threads", "1", "-movflags", "+faststart", "-map_metadata", "-1",
             "-fflags", "+bitexact", "-flags:v", "+bitexact", str(self.path)],
            stdin=subprocess.PIPE)
        self.frames = 0

    def add(self, fig):
        fig.canvas.draw()
        rgba = np.asarray(fig.canvas.buffer_rgba())
        assert rgba.shape[:2] == (1080, 1920), rgba.shape
        self.proc.stdin.write(np.ascontiguousarray(rgba[:, :, :3]).tobytes())
        self.frames += 1

    def close(self):
        self.proc.stdin.close()
        if self.proc.wait() != 0:
            raise RuntimeError(f"ffmpeg failed for {self.path}")
        return self.frames / FPS


def style_axes(ax):
    for spine in ax.spines.values():
        spine.set_color(MUTED)
    ax.tick_params(colors=TEXT, length=6)


# ---------------------------------------------------------------- data

COLS = ("elapsed_us", "measured_x_urad", "measured_y_urad",
        "commanded_x_urad", "commanded_y_urad")


def read_complete_rows(path):
    """The disturbance-run rows that carry every column we use. Frames read
    from a host backlog carry no command; those rows are skipped, not filled."""
    total = 0
    keep = {k: [] for k in COLS}
    with open(path, newline="") as handle:
        for row in csv.DictReader(handle):
            total += 1
            if any(row[k] == "" for k in COLS):
                continue
            for k in COLS:
                keep[k].append(float(row[k]))
    run = {k: np.array(v) for k, v in keep.items()}
    run["t"] = run["elapsed_us"] * 1e-6
    run["rows_total"] = total
    run["rows_used"] = len(run["t"])
    return run


def circle_metrics(run):
    cx, cy = run["commanded_x_urad"], run["commanded_y_urad"]
    mx, my = run["measured_x_urad"], run["measured_y_urad"]
    err = np.hypot(mx - cx, my - cy)
    radius_cmd = np.hypot(cx, cy)
    # Gains use the release analysis's selection (commanded radius above 85 %
    # of its peak, which takes in the last of the ramps) so they compare
    # directly with the release figures.
    near = radius_cmd > 0.85 * radius_cmd.max()
    gains = {a: float(np.polyfit(c[near], m[near], 1)[0])
             for a, c, m in (("x", cx, mx), ("y", cy, my))}
    # "On the circle" for the error figures: commanded radius at its peak,
    # i.e. the laps alone.
    on = radius_cmd > 0.999 * radius_cmd.max()
    fit = json.loads((RC / "circle-frames.circle.json").read_text())
    return {
        "rows_total": run["rows_total"],
        "rows_used": run["rows_used"],
        "rows_gain_selection": int(near.sum()),
        "rows_on_circle": int(on.sum()),
        "commanded_radius_urad": float(radius_cmd.max()),
        "profile_radius_urad": fit["radius_urad"],
        "profile_period_s": fit["period_s"],
        "gain_x": gains["x"], "gain_y": gains["y"],
        "error_rms_all_urad": float(np.sqrt(np.mean(err ** 2))),
        "error_max_all_urad": float(err.max()),
        "error_rms_on_circle_urad": float(np.sqrt(np.mean(err[on] ** 2))),
        "error_max_on_circle_urad": float(err[on].max()),
        "lag_ms_circle_fit": (fit["x"]["lag_ms"] + fit["y"]["lag_ms"]) / 2,
        "lag_cycles_circle_fit": (fit["x"]["lag_cycles"] + fit["y"]["lag_cycles"]) / 2,
    }, err, on


def step_metrics(run, axis, level):
    """The rising edge to `level` on `axis`: rise time 10-90 %, dead time to
    the first 10 %, overshoot, and 2 % settling (last exit from the ±2 % band
    within the pulse)."""
    t = run["t"] * 1e3
    c = run[f"commanded_{axis}_urad"]
    m = run[f"measured_{axis}_urad"]
    edges = np.flatnonzero((np.diff(c) != 0) & (c[1:] == level)) + 1
    i0 = int(edges[0])
    t0 = t[i0]
    base = float(m[(t > t0 - 250) & (t < t0)].mean())
    end = np.flatnonzero(np.diff(c[i0:]) != 0)
    i1 = i0 + int(end[0]) + 1 if len(end) else len(c)
    final = float(m[i1 - 500:i1 - 1].mean())
    tt, mm = t[i0:i1] - t0, m[i0:i1]
    frac = (mm - base) / (level)
    t10 = float(tt[np.argmax(frac >= 0.10)])
    t90 = float(tt[np.argmax(frac >= 0.90)])
    band = 0.02 * abs(level)
    outside = np.flatnonzero(np.abs(mm - (base + level)) > band)
    settle = float(tt[outside[-1] + 1]) if len(outside) else 0.0
    peak = float(mm.max())
    overshoot = max(0.0, (peak - (base + level)) / level * 100)
    return {
        "axis": axis, "level_urad": level, "edge_index": i0, "edge_time_ms": float(t0),
        "baseline_urad": base, "final_urad": final, "gain": (final - base) / level,
        "t10_ms": t10, "t90_ms": t90, "rise_10_90_ms": t90 - t10,
        "settle_2pct_ms": settle, "overshoot_pct": overshoot, "band_urad": band,
    }


LOG_LINE = re.compile(r"\[\s*([\d.]+) ms ->\s*([\d.na]+) ms\] (.*?): (.*)$")


def read_commit_log(path):
    events = []
    for line in path.read_text().splitlines():
        match = LOG_LINE.search(line)
        if not match:
            continue
        sent, replied, what, reply = match.groups()
        replied = float(replied) if replied != "nan" else None
        if "outcome': '" in reply:
            outcome = reply.split("outcome': '")[1].split("'")[0]
        elif reply.startswith("Busy"):
            outcome = "Busy"
        elif what.startswith("status") or what == "version":
            outcome = "answered"
        else:
            outcome = "none"
        events.append({"sent": float(sent), "reply": replied, "what": what,
                       "outcome": outcome, "raw": reply})
    return events


def read_commit_telemetry(path):
    host, cycle, err = [], [], []
    with open(path, newline="") as handle:
        for row in csv.DictReader(handle):
            if any(row[k] == "" for k in ("host_ms", "cycle", "errors")):
                continue
            host.append(float(row["host_ms"]))
            cycle.append(int(row["cycle"]))
            err.append(int(row["errors"], 16))
    return np.array(host), np.array(cycle), np.array(err)


# ---------------------------------------------------------------- circle

LAPS_FROM_S, LAPS_TO_S = 1.5, 5.5    # two full laps, after the ramp out


class CircleScene:
    def __init__(self, run, metrics, err, on, video=False):
        self.run, self.metrics, self.err, self.on = run, metrics, err, on
        title = (f"Circle tracking: {metrics['profile_radius_urad']:.0f} µrad radius, "
                 f"{metrics['profile_period_s']:.0f} s per lap")
        if video:
            title += " — replay at real time (1×)"
        self.fig = new_frame(title)
        fig = self.fig
        t = run["t"]
        cx, cy = run["commanded_x_urad"], run["commanded_y_urad"]
        mx, my = run["measured_x_urad"], run["measured_y_urad"]

        # XY plane
        self.xy = fig.add_axes([0.065, 0.36, 0.28, 0.47])
        xy = self.xy
        style_axes(xy)
        lim = 1000
        xy.set_xlim(-lim, lim)
        xy.set_ylim(-lim, lim)
        xy.set_aspect("equal", adjustable="box")
        xy.set_xlabel("x (µrad)")
        xy.set_ylabel("y (µrad)", labelpad=2)
        xy.set_xticks([-800, -400, 0, 400, 800])
        xy.set_yticks([-800, -400, 0, 400, 800])

        # Lag detail: a ±40 µrad window riding on the trace
        self.zoom = fig.add_axes([0.395, 0.36, 0.28, 0.47])
        zoom = self.zoom
        style_axes(zoom)
        zoom.set_aspect("equal", adjustable="box")
        zoom.set_xlabel("Δx from commanded (µrad)")
        zoom.set_ylabel("Δy (µrad)", labelpad=2)
        zoom.set_title("Zoom ±40 µrad on the moving point", color=TEXT, pad=10)

        # Error strip
        self.strip = fig.add_axes([0.06, 0.115, 0.92, 0.155])
        strip = self.strip
        style_axes(strip)
        strip.set_xlabel("time since run start (s)")
        strip.set_ylabel("|error| (µrad)")
        strip.set_ylim(0, 25)
        strip.set_yticks([0, 10, 20])

        if video:
            sel = (t >= LAPS_FROM_S) & (t <= LAPS_TO_S)
            strip.set_xlim(LAPS_FROM_S, LAPS_TO_S)
            xy.plot(cx[sel], cy[sel], color=MUTED, lw=1.0, alpha=0.6)
        else:
            sel = np.ones_like(t, dtype=bool)
            strip.set_xlim(0, t[-1])
            # shade the laps so the ramp in / out reads as such
            t_on = t[on]
            strip.axvspan(t_on[0], t_on[-1], color=MUTED, alpha=0.18, lw=0)
            strip.text(t_on[0] + 0.05, 23, "on the circle", color=TEXT, fontsize=17, va="top")
            strip.text(0.05, 23, "ramp from centre", color=MUTED, fontsize=17, va="top")
            strip.text(t[-1] - 0.05, 23, "ramp to centre", color=MUTED, fontsize=17, va="top",
                       ha="right")
        self.sel = np.flatnonzero(sel)

        self.cmd_line, = xy.plot([], [], color=BLUE, lw=3.0, label="commanded", zorder=3)
        self.meas_line, = xy.plot([], [], color=ORANGE, lw=1.6, label="measured", zorder=4)
        self.cmd_dot, = xy.plot([], [], "o", color=BLUE, ms=14, zorder=5)
        self.meas_dot, = xy.plot([], [], "o", color=ORANGE, ms=10, zorder=6)
        xy.set_title("Full plane (traces overlap)", color=TEXT, pad=10)
        zoom.legend(handles=[self.cmd_line, self.meas_line], loc="upper right", fontsize=18,
                    handlelength=1.5)

        self.err_line, = strip.plot([], [], color=RED, lw=1.4)
        self.err_cursor = strip.axvline(np.nan, color=TEXT, lw=1.2, alpha=0.8)

        self.z_cmd, = zoom.plot([], [], color=BLUE, lw=3.0)
        self.z_meas, = zoom.plot([], [], color=ORANGE, lw=2.0)
        self.z_cdot, = zoom.plot([], [], "o", color=BLUE, ms=18, zorder=5)
        self.z_mdot, = zoom.plot([], [], "o", color=ORANGE, ms=14, zorder=6)
        self.z_vec, = zoom.plot([], [], color=RED, lw=3.0, zorder=7)
        self.z_label = zoom.text(0.03, 0.04, "", transform=zoom.transAxes, fontsize=18,
                                 color=RED, va="bottom")
        zoom.set_xlim(-40, 40)
        zoom.set_ylim(-40, 40)
        zoom.set_xticks([-40, -20, 0, 20, 40])
        zoom.set_yticks([-40, -20, 0, 20, 40])

        self.readout = None
        self._stats_panel(video)

    def _stats_panel(self, video):
        m = self.metrics
        fig = self.fig
        x0, y = 0.705, 0.80
        lines = [
            ("Measured gain on the circle", None, TEXT, 21, "bold"),
            (f"x {m['gain_x']:.4f}    y {m['gain_y']:.4f}", None, GREEN, 26, "bold"),
            ("", None, TEXT, 8, "normal"),
            ("Tracking error, whole run", None, TEXT, 21, "bold"),
            (f"{m['error_rms_all_urad']:.1f} µrad rms,  {m['error_max_all_urad']:.1f} max",
             None, GREEN, 26, "bold"),
            ("release-bench figure (incl. ramps)", None, MUTED, 17, "normal"),
            ("", None, TEXT, 8, "normal"),
            ("Tracking error, on the circle only", None, TEXT, 21, "bold"),
            (f"{m['error_rms_on_circle_urad']:.1f} µrad rms,  "
             f"{m['error_max_on_circle_urad']:.1f} max", None, GREEN, 26, "bold"),
            (f"≈ {m['lag_ms_circle_fit']:.1f} ms lag along the path (circle fit)",
             None, MUTED, 17, "normal"),
            ("", None, TEXT, 8, "normal"),
            (f"{m['rows_used']} frames at ~2 kHz, 0 error flags", None, TEXT, 18, "normal"),
        ]
        for text, _, color, size, weight in lines:
            fig.text(x0, y, text, color=color, fontsize=size, fontweight=weight, va="top")
            y -= size / 72 * 1.45 / H
        if video:
            self.readout = fig.text(x0, y - 0.01, "", color=TEXT, fontsize=22, va="top",
                                    family="DejaVu Sans Mono")

    def draw_until(self, idx):
        """Draw the trace through sample `idx` (an index into the run)."""
        run = self.run
        t = run["t"]
        cx, cy = run["commanded_x_urad"], run["commanded_y_urad"]
        mx, my = run["measured_x_urad"], run["measured_y_urad"]
        s = self.sel[(self.sel <= idx)]
        self.cmd_line.set_data(cx[s], cy[s])
        self.meas_line.set_data(mx[s], my[s])
        self.cmd_dot.set_data([cx[idx]], [cy[idx]])
        self.meas_dot.set_data([mx[idx]], [my[idx]])
        self.err_line.set_data(t[s], self.err[s])
        self.err_cursor.set_xdata([t[idx], t[idx]])
        # zoom window centred on the commanded point at this instant
        ox, oy = cx[idx], cy[idx]
        tail = s[s >= idx - 120]
        lead = np.arange(idx, min(idx + 40, len(t)))
        self.z_cmd.set_data(np.r_[cx[tail], cx[lead]] - ox, np.r_[cy[tail], cy[lead]] - oy)
        self.z_meas.set_data(np.r_[mx[tail], mx[lead]] - ox, np.r_[my[tail], my[lead]] - oy)
        self.z_cdot.set_data([0], [0])
        self.z_mdot.set_data([mx[idx] - ox], [my[idx] - oy])
        self.z_vec.set_data([0, mx[idx] - ox], [0, my[idx] - oy])
        self.z_label.set_text(f"error now {self.err[idx]:.1f} µrad")
        if self.readout is not None:
            self.readout.set_text(f"t = {t[idx]:6.3f} s\n|err| = {self.err[idx]:5.1f} µrad")


def render_circle(video):
    run = read_complete_rows(RC / "circle-frames.csv")
    metrics, err, on = circle_metrics(run)
    t = run["t"]

    scene = CircleScene(run, metrics, err, on, video=False)
    # still: whole run drawn; zoom detail at the commanded 45° point of lap 1
    lap = np.flatnonzero(on & (t >= LAPS_FROM_S))
    ang = np.degrees(np.arctan2(run["commanded_y_urad"][lap], run["commanded_x_urad"][lap]))
    pick = int(lap[np.argmin(np.abs(ang - 45))])
    scene.draw_until(len(t) - 1)
    # put the dots and the zoom on the picked instant
    scene.cmd_dot.set_data([run["commanded_x_urad"][pick]], [run["commanded_y_urad"][pick]])
    scene.meas_dot.set_data([run["measured_x_urad"][pick]], [run["measured_y_urad"][pick]])
    full = scene.sel
    scene.sel = full[full <= pick + 40]
    keep = (scene.cmd_line.get_data(), scene.meas_line.get_data(), scene.err_line.get_data())
    scene.draw_until(pick)
    scene.cmd_line.set_data(*keep[0])
    scene.meas_line.set_data(*keep[1])
    scene.err_line.set_data(*keep[2])
    scene.err_cursor.set_xdata([t[pick], t[pick]])
    scene.zoom.set_title(f"Zoom ±40 µrad at t = {t[pick]:.3f} s",
                         color=TEXT, pad=10)
    out = [save_png(scene.fig, "circle.png")]

    duration = None
    if video:
        scene = CircleScene(run, metrics, err, on, video=True)
        writer = VideoWriter("circle.mp4")
        first = int(np.searchsorted(t, LAPS_FROM_S))
        n_frames = int(round((LAPS_TO_S - LAPS_FROM_S) * FPS))
        scene.draw_until(first)
        for _ in range(FPS):                      # 1 s hold on the start
            writer.add(scene.fig)
        for k in range(1, n_frames + 1):
            ts = LAPS_FROM_S + k / FPS
            idx = min(int(np.searchsorted(t, ts, side="right")) - 1, len(t) - 1)
            scene.draw_until(idx)
            writer.add(scene.fig)
        for _ in range(3 * FPS):                  # 3 s hold on the end
            writer.add(scene.fig)
        duration = writer.close()
        plt.close(scene.fig)
        out.append(writer.path)
    return metrics, out, duration


# ---------------------------------------------------------------- steps

STEP_LEVEL = 100.0
STEP_WINDOW_MS = (-5.0, 45.0)


def render_steps():
    fig = new_frame(f"Step response: +{STEP_LEVEL:.0f} µrad commanded on each axis")
    results = []
    for k, axis in enumerate(("x", "y")):
        run = read_complete_rows(RC / f"step-{axis}.csv")
        sm = step_metrics(run, axis, STEP_LEVEL)
        results.append(sm)
        ax = fig.add_axes([0.06 + k * 0.48, 0.17, 0.42, 0.62])
        style_axes(ax)
        t = run["t"] * 1e3 - sm["edge_time_ms"]
        sel = (t >= STEP_WINDOW_MS[0]) & (t <= STEP_WINDOW_MS[1])
        c = run[f"commanded_{axis}_urad"][sel] - sm["baseline_urad"]
        m = run[f"measured_{axis}_urad"][sel] - sm["baseline_urad"]
        ax.axhspan(STEP_LEVEL - sm["band_urad"], STEP_LEVEL + sm["band_urad"],
                   color=GREEN, alpha=0.18, lw=0)
        ax.step(t[sel], c, where="post", color=BLUE, lw=3.0, label="commanded")
        ax.plot(t[sel], m, color=ORANGE, lw=2.4, marker="o", ms=3.5, label="measured")
        ax.set_xlim(*STEP_WINDOW_MS)
        ax.set_ylim(-8, 112)
        ax.set_xlabel("time from command edge (ms)")
        ax.set_ylabel(f"{axis} position (µrad, from baseline)")
        ax.set_title(f"{axis.upper()} axis", color=TEXT, fontsize=24, fontweight="bold", pad=10)
        ts = sm["settle_2pct_ms"]
        ax.axvline(ts, color=GREEN, lw=2, ls="--")
        ax.text(ts + 0.8, 58, f"settled within ±2 %\nat {ts:.1f} ms",
                color=GREEN, fontsize=19, fontweight="bold", va="center")
        for tf, level in ((sm["t10_ms"], 0.1), (sm["t90_ms"], 0.9)):
            ax.plot([tf], [level * STEP_LEVEL], "o", ms=12, mfc="none", mec=TEXT, mew=2)
        ax.annotate(f"10–90 % rise {sm['rise_10_90_ms']:.1f} ms",
                    xy=(sm["t90_ms"], 0.9 * STEP_LEVEL), xytext=(ts + 0.8, 78),
                    color=TEXT, fontsize=19, va="center",
                    arrowprops=dict(arrowstyle="->", color=TEXT, lw=1.6))
        ax.text(0.98, 0.04,
                f"overshoot {sm['overshoot_pct']:.1f} %\n"
                f"step gain {sm['gain']:.4f}",
                transform=ax.transAxes, ha="right", va="bottom", fontsize=18, color=TEXT,
                bbox=dict(facecolor=BG, edgecolor=MUTED, boxstyle="round,pad=0.4"))
        if k == 0:
            ax.legend(loc="lower right", bbox_to_anchor=(0.99, 0.2), fontsize=18)
    fig.text(0.5, 0.075,
             "Shaded band: ±2 % of the step. One 1 s pulse from the 20–400 µrad "
             "ladder; release-bench mean step gain x 1.0001, y 1.0000.",
             ha="center", color=TEXT, fontsize=18)
    return results, save_png(fig, "steps.png")


# ---------------------------------------------------------------- B5 commit

B5_WINDOW = (-120.0, 1160.0)
B5_ZOOM = (-1.0, 26.0)
LANES = ["flash write", "other → Busy", "status/version", "setpoints"]


def lane_of(ev):
    w, o = ev["what"], ev["outcome"]
    if o in ("Accepted", "Complete", "TransactionConflict"):
        return 0
    if o == "Busy":
        return 1
    if o == "answered":
        return 2
    if w.startswith("setpoint"):
        return 3
    return None


def ev_color(ev):
    return {"Accepted": BLUE, "Complete": GREEN, "TransactionConflict": RED,
            "Busy": RED, "answered": ORANGE}.get(ev["outcome"], MUTED)


def lane_axes(fig, rect, xlim, xlabel, sharex=None):
    ax = fig.add_axes(rect, sharex=sharex)
    style_axes(ax)
    ax.set_xlim(*xlim)
    ax.set_ylim(len(LANES) - 0.5, -0.5)
    ax.set_yticks(range(len(LANES)))
    ax.set_yticklabels(LANES, fontsize=18)
    ax.grid(axis="y", visible=False)
    ax.set_xlabel(xlabel, labelpad=2)
    return ax


class CommitScene:
    def __init__(self, events, host, cycle, err, video=False):
        self.events, self.host, self.cycle, self.err = events, host, cycle, err
        title = "Calibration-record commit (B5): telemetry pauses while flash is written"
        if video:
            title = ""
        self.fig = new_frame(title, SOURCE_B5)
        self.title = self.fig.text(0.02, 0.885, "", ha="left", va="center", fontsize=30,
                                   fontweight="bold", color=TEXT)
        fig = self.fig
        self.ref_cycle = int(cycle[host < 0][-1])
        last_pre = np.flatnonzero(host <= 1.5)[-1]
        g0, g1 = float(host[last_pre]), float(host[last_pre + 1])
        dc = int(cycle[last_pre + 1] - cycle[last_pre])
        self.gap = (g0, g1, dc)
        self.reveal = []       # (time, artist): shown once the clock passes time

        # --- telemetry stream
        tel = fig.add_axes([0.145, 0.625, 0.835, 0.19])
        style_axes(tel)
        tel.set_xlim(*B5_WINDOW)
        tel.set_ylim(-400, 2700)
        tel.set_yticks([0, 1000, 2000])
        tel.set_ylabel("board cycle\n− 900023", fontsize=18)
        tel.tick_params(labelbottom=False)
        self.gap_spans = [self._gap_span(tel, 0.13)]
        fig.text(0.145, 0.83, "Telemetry frames (about 2 per ms; board cycle = 0.5 ms)",
                 fontsize=20, fontweight="bold", color=TEXT, va="bottom")
        self.tel_ok, = tel.plot([], [], "o", color=GREEN, ms=3)
        self.tel_bad, = tel.plot([], [], "o", color=RED, ms=13)
        gap_text = tel.text(
            400, 1500,
            f"no telemetry for {g1 - g0:.1f} ms of host time\n"
            f"board cycle steps {dc} = {dc * 0.5:.1f} ms ({dc - 1} cycles without a frame)",
            ha="center", va="center", fontsize=20, color=RED, fontweight="bold")
        self.reveal.append((g1, gap_text))
        bad = np.flatnonzero(err != 0)
        if len(bad):
            a = tel.annotate("first frame after the gap flags\nMESSAGE_REFUSED (0x400) "
                             "for the refused setpoints",
                             xy=(host[bad[0]], cycle[bad[0]] - self.ref_cycle),
                             xytext=(host[bad[0]] - 40, 300), fontsize=17, color=RED,
                             ha="right", va="center",
                             arrowprops=dict(arrowstyle="->", color=RED, lw=1.6))
            self.reveal.append((host[bad[0]], a))
        self.tel = tel

        # --- request / reply lanes, whole window
        lanes = lane_axes(fig, [0.145, 0.405, 0.835, 0.17], B5_WINDOW,
                          "host time from the first write request (ms)", sharex=tel)
        lanes.tick_params(labelbottom=True)
        self.gap_spans.append(self._gap_span(lanes, 0.08))
        lanes.axvspan(*B5_ZOOM, color=TEXT, alpha=0.12, lw=0)
        fig.text(0.145, 0.585, "Host requests and the board's replies (bar: request → reply)",
                 fontsize=20, fontweight="bold", color=TEXT, va="bottom")
        self.lanes = lanes

        # --- zoom on the opening milliseconds
        zoom = lane_axes(fig, [0.145, 0.115, 0.835, 0.17], B5_ZOOM,
                         f"host time (ms), first {B5_ZOOM[1]:.0f} ms (shaded above)")
        fig.text(0.145, 0.295, "First 26 ms: other requests get Busy; status and version "
                 "are still answered",
                 fontsize=20, fontweight="bold", color=TEXT, va="bottom")
        self.zoom = zoom

        for ev in events:
            lane = lane_of(ev)
            if lane is None:
                continue
            col = ev_color(ev)
            big = ev["outcome"] == "Complete" or ev["what"] == "write (first)"
            for ax, (lo, hi), inzoom in ((lanes, B5_WINDOW, False), (zoom, B5_ZOOM, True)):
                if not lo <= ev["sent"] <= hi:
                    continue
                if ev["reply"] is not None:
                    seg, = ax.plot([ev["sent"], ev["reply"]], [lane, lane], color=col,
                                   lw=9 if inzoom else 5, solid_capstyle="butt")
                    dot, = ax.plot([ev["reply"]], [lane], "o", color=col,
                                   ms=18 if big else (12 if inzoom else 7))
                    self.reveal += [(ev["sent"], seg), (ev["reply"], dot)]
                else:
                    mark, = ax.plot([ev["sent"]], [lane], "x", color=TEXT, ms=16, mew=3)
                    self.reveal.append((ev["sent"], mark))

        def zoom_label(t, lane, text, color, ha="left", dy=0.0):
            artist = zoom.text(t, lane + dy, text, fontsize=17, color=color, ha=ha,
                               va="center")
            self.reveal.append((t if ha == "left" else 0.0, artist))

        zoom_label(4.9, 0, "← write Accepted at 1.2 ms, resend Accepted; other "
                   "record on same txn → Conflict", BLUE)
        zoom_label(15.5, 1, "← 7 other requests → Busy", RED)
        zoom_label(15.1, 2, "status 16.4 ms, version 18.3 ms, status ×3 →", ORANGE,
                   ha="right")
        zoom_label(17.9, 3, "setpoints Shutdown, Idle: no reply, refused →", TEXT, ha="right")

        # --- callouts on the whole-window lanes
        done = next(e for e in events if e["outcome"] == "Complete")
        a = lanes.text(500, 0, "resends every ~12 ms: all Accepted (write still in progress)",
                       fontsize=17, color=BLUE, ha="center", va="center",
                       bbox=dict(facecolor=BG, edgecolor="none", pad=2))
        self.reveal.append((40.0, a))
        a = lanes.text(500, 2, "status polls every ~107 ms answered throughout",
                       fontsize=17, color=ORANGE, ha="center", va="center",
                       bbox=dict(facecolor=BG, edgecolor="none", pad=2))
        self.reveal.append((140.0, a))
        a = lanes.annotate(f"Complete at {done['reply']:.1f} ms", xy=(done["reply"], 0),
                           xytext=(done["reply"] - 30, 1.0), fontsize=20, fontweight="bold",
                           color=GREEN, ha="right", va="center",
                           bbox=dict(facecolor=BG, edgecolor="none", pad=2),
                           arrowprops=dict(arrowstyle="->", color=GREEN, lw=2))
        self.reveal.append((done["reply"], a))

        self.clock = None
        self.cursors = []
        if video:
            self.clock = fig.text(0.98, 0.885, "", ha="right", va="center", fontsize=28,
                                  family="DejaVu Sans Mono", color=TEXT)
            for ax in (tel, lanes, zoom):
                self.cursors.append(ax.axvline(np.nan, color=TEXT, lw=1.5, alpha=0.8))

    def _gap_span(self, ax, alpha):
        g0, g1, _ = self.gap
        span = Rectangle((g0, 0), g1 - g0, 1, transform=blended_transform_factory(
            ax.transData, ax.transAxes), facecolor=RED, alpha=alpha, lw=0, zorder=0)
        ax.add_patch(span)
        return span

    def draw_until(self, now, slow=None):
        host, cycle, err = self.host, self.cycle, self.err
        g0, g1, _ = self.gap
        for span in self.gap_spans:
            span.set_width(max(0.0, min(now, g1) - g0))
        if slow is not None:
            self.title.set_text(f"B5 commit \u2014 replay slowed {slow:g}\u00d7")
        sel = (host >= B5_WINDOW[0]) & (host <= now)
        ok = sel & (err == 0)
        bad = sel & (err != 0)
        self.tel_ok.set_data(host[ok], cycle[ok] - self.ref_cycle)
        self.tel_bad.set_data(host[bad], cycle[bad] - self.ref_cycle)
        for t, artist in self.reveal:
            artist.set_visible(t <= now)
        if self.clock is not None:
            self.clock.set_text(f"host t = {now:7.1f} ms")
            for c in self.cursors:
                c.set_xdata([now, now])


def render_commit(video):
    events = read_commit_log(B5 / "commit.log")
    host, cycle, err = read_commit_telemetry(B5 / "commit-telemetry.csv")
    scene = CommitScene(events, host, cycle, err)
    scene.draw_until(B5_WINDOW[1])
    out = [save_png(scene.fig, "b5-commit.png")]
    g0, g1, dc = scene.gap
    facts = {"gap_host_ms": g1 - g0, "gap_cycles": dc, "gap_board_ms": dc * 0.5,
             "complete_reply_ms": next(e["reply"] for e in events if e["outcome"] == "Complete"),
             "busy_replies": sum(e["outcome"] == "Busy" for e in events),
             "answered": sum(e["outcome"] == "answered" for e in events)}
    duration = None
    if video:
        scene = CommitScene(events, host, cycle, err, video=True)
        writer = VideoWriter("b5-commit.mp4")
        # 10x slower than real time, except the opening 26 ms (the zoom
        # panel), which plays 100x slower; the title states the rate in force.
        segments = [(B5_WINDOW[0], 0.0, 10.0), (0.0, B5_ZOOM[1], 100.0),
                    (B5_ZOOM[1], B5_WINDOW[1], 10.0)]
        scene.draw_until(B5_WINDOW[0], slow=10.0)
        for _ in range(FPS):
            writer.add(scene.fig)
        for start, stop, slow in segments:
            n = int(round((stop - start) / 1000 * slow * FPS))
            for k in range(1, n + 1):
                scene.draw_until(start + k * (stop - start) / n, slow=slow)
                writer.add(scene.fig)
        for _ in range(3 * FPS):
            writer.add(scene.fig)
        duration = writer.close()
        plt.close(scene.fig)
        out.append(writer.path)
    return facts, out, duration


# ---------------------------------------------------------------- main

def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--no-video", action="store_true", help="stills only")
    args = parser.parse_args()
    video = not args.no_video

    circle, circle_out, circle_dur = render_circle(video)
    steps, steps_out = render_steps()
    commit, commit_out, commit_dur = render_commit(video)

    summary = {
        "circle": circle, "steps": steps, "b5_commit": commit,
        "videos_s": {"circle.mp4": circle_dur, "b5-commit.mp4": commit_dur},
        "release_reference": json.loads((RC / "analysis" / "summary.json").read_text())
        ["runs"]["circle-frames"],
    }
    (HERE / "computed.json").write_text(json.dumps(summary, indent=2, default=float) + "\n")
    for p in circle_out + [steps_out] + commit_out:
        print("wrote", p.name)
    print(json.dumps({k: summary[k] for k in ("circle", "b5_commit", "videos_s")},
                     indent=2, default=float))
    for s in steps:
        print(f"step {s['axis']}: rise {s['rise_10_90_ms']:.2f} ms, settle {s['settle_2pct_ms']:.2f} ms,"
              f" overshoot {s['overshoot_pct']:.2f} %, gain {s['gain']:.4f}")


if __name__ == "__main__":
    main()
